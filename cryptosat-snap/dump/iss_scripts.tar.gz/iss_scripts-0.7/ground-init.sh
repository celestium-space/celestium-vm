#!/usr/bin/bash
set -e

echo "Ground station initialization completed (v2)"
