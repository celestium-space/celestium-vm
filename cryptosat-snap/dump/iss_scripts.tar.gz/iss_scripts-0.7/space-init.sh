#!/bin/bash
set -e

./pos-space-init.sh

echo "ISS initialization completed (v2)"
